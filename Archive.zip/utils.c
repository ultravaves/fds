#include "utils.h"

#include <stddef.h>

#include "lexer.h"

int validate_tokens(const TokenList *list) {
    int balance = 0;
    const Token *prev = NULL;
    for (const Token *cur = list->head; cur; prev = cur, cur = cur->next) {
        if (cur->type == TOK_LPAREN) {
            balance++;
            if (cur->next && cur->next->type == TOK_RPAREN) return 0;  // пустые скобки
        } else if (cur->type == TOK_RPAREN) {
            balance--;
            if (balance < 0) return 0;  // лишняя закрывающая скобка
        } else if (cur->type == TOK_OPERATOR &&
                   (!prev || prev->type == TOK_OPERATOR || prev->type == TOK_LPAREN))
            return 0;  // два оператора подряд или в начале
        else if (cur->type == TOK_FUNCTION && (!cur->next || cur->next->type != TOK_LPAREN))
            return 0;  // функция не за скобками
    }
    return balance == 0;
}
