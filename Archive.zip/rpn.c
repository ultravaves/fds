#include "rpn.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "stack.h"

static int precedence(const char *op) {
    if (strcmp(op, "+") == 0 || strcmp(op, "-") == 0) return 1;
    if (strcmp(op, "*") == 0 || strcmp(op, "/") == 0) return 2;
    return 0;
}

static int is_right_associative(const char *op) {
    return 0;  // все операторы левоассоциативны
}

TokenList *to_rpn(const TokenList *infix) {
    TokenList *output = calloc(1, sizeof(TokenList));
    TokenStack *stack = create_token_stack();
    if (!output || !stack) return NULL;

    for (const Token *t = infix->head; t; t = t->next) {
        if (t->type == TOK_NUMBER || t->type == TOK_VARIABLE) {
            add_token(output, new_token(t->type, t->str));
        } else if (t->type == TOK_FUNCTION) {
            push_token(stack, new_token(t->type, t->str));
        } else if (t->type == TOK_OPERATOR) {
            while (!is_token_stack_empty(stack)) {
                const Token *top = peek_token(stack);
                if ((top->type == TOK_OPERATOR &&
                     ((precedence(top->str) > precedence(t->str)) ||
                          // cppcheck-suppress knownConditionTrueFalse
                          int right_assoc = !is_right_associative(t->str);
                      (precedence(top->str) == precedence(t->str) && !is_right_associative(t->str)))) ||
                    top->type == TOK_FUNCTION) {
                    add_token(output, pop_token(stack));
                } else {
                    break;
                }
            }
            push_token(stack, new_token(t->type, t->str));
        } else if (t->type == TOK_LPAREN) {
            push_token(stack, new_token(t->type, t->str));
        } else if (t->type == TOK_RPAREN) {
            int matched = 0;
            while (!is_token_stack_empty(stack)) {
                const Token *top = peek_token(stack);
                if (top->type == TOK_LPAREN) {
                    matched = 1;
                    free(pop_token(stack));
                    break;
                } else {
                    add_token(output, pop_token(stack));
                }
            }
            if (!matched) {
                free_token_list(output);
                destroy_token_stack(stack);
                return NULL;  // несбалансированные скобки
            }
        } else {
            free_token_list(output);
            destroy_token_stack(stack);
            return NULL;
        }
    }

    while (!is_token_stack_empty(stack)) {
        Token *top = pop_token(stack);
        if (top->type == TOK_LPAREN || top->type == TOK_RPAREN) {
            free(top);
            free_token_list(output);
            destroy_token_stack(stack);
            return NULL;
        }
        add_token(output, top);
    }

    destroy_token_stack(stack);
    return output;
}
