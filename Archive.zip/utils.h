#ifndef UTILS_H
#define UTILS_H

#include "lexer.h"

// Проверка списка токенов на логическую корректность:
// - сбалансированность скобок
// - отсутствие пустых скобок
// - правильная структура функций и операторов
int validate_tokens(TokenList *list);

#endif
