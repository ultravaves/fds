#ifndef RPN_H
#define RPN_H

#include "lexer.h"

TokenList *to_rpn(TokenList *infix);

#endif
