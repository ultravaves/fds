#include "lexer.h"

#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

const char *functions[] = {"sin", "cos", "tan", "ctg", "sqrt", "ln", NULL};
const char operators[] = "+-*/";

Token *new_token(TokenType type, const char *str) {
    Token *token = malloc(sizeof(Token));
    if (!token) return NULL;
    token->type = type;
    strncpy(token->str, str, 15);
    token->str[15] = '\0';
    token->next = NULL;
    return token;
}

void add_token(TokenList *list, Token *token) {
    if (!list->head) {
        list->head = list->tail = token;
    } else {
        list->tail->next = token;
        list->tail = token;
    }
}

static int is_function(const char *start, int *len_out) {
    for (int i = 0; functions[i]; ++i) {
        int len = strlen(functions[i]);
        if (strncmp(start, functions[i], len) == 0) {
            *len_out = len;
            return 1;
        }
    }
    return 0;
}

TokenList *tokenize(const char *input) {
    TokenList *list = calloc(1, sizeof(TokenList));
    if (!list) return NULL;

    const char *p = input;
    while (*p) {
        if (isspace(*p)) {
            p++;
            continue;
        }

        if (isdigit(*p) || ((*p == '-' || *p == '+') && isdigit(*(p + 1)))) {
            char number[16] = {0};
            int i = 0;
            if (*p == '-' || *p == '+') number[i++] = *p++;
            while ((isdigit(*p) || *p == '.' || *p == ',') && i < 15) {
                number[i++] = (*p == ',') ? '.' : *p;
                p++;
            }
            add_token(list, new_token(TOK_NUMBER, number));
        } else if (isalpha(*p)) {
            int len;
            if (is_function(p, &len)) {
                char func[16] = {0};
                strncpy(func, p, len);
                add_token(list, new_token(TOK_FUNCTION, func));
                p += len;
            } else if (*p == 'x') {
                add_token(list, new_token(TOK_VARIABLE, "x"));
                p++;
            } else {
                free_token_list(list);
                return NULL;
            }
        } else if (strchr(operators, *p)) {
            const char op[2] = {*p, '\0'};
            add_token(list, new_token(TOK_OPERATOR, op));
            p++;
        } else if (*p == '(') {
            add_token(list, new_token(TOK_LPAREN, "("));
            p++;
        } else if (*p == ')') {
            add_token(list, new_token(TOK_RPAREN, ")"));
            p++;
        } else {
            free_token_list(list);
            return NULL;
        }
    }

    return list;
}

void free_token_list(TokenList *list) {
    if (!list) return;
    Token *cur = list->head;
    while (cur) {
        Token *tmp = cur;
        cur = cur->next;
        free(tmp);
    }
    free(list);
}
