#include "stack.h"

#include <stdlib.h>

TokenStack *create_token_stack() {
    TokenStack *stack = malloc(sizeof(TokenStack));
    if (stack) stack->top = NULL;
    return stack;
}

void destroy_token_stack(TokenStack *stack) {
    if (!stack) return;
    TokenNode *curr = stack->top;
    while (curr) {
        TokenNode *tmp = curr;
        curr = curr->next;
        free(tmp->token);
        free(tmp);
    }
    free(stack);
}

void push_token(TokenStack *stack, Token *token) {
    if (!stack || !token) return;
    TokenNode *node = malloc(sizeof(TokenNode));
    if (!node) return;
    node->token = token;
    node->next = stack->top;
    stack->top = node;
}

Token *pop_token(TokenStack *stack) {
    if (!stack || !stack->top) return NULL;
    TokenNode *node = stack->top;
    stack->top = node->next;
    Token *token = node->token;
    free(node);
    return token;
}

Token *peek_token(TokenStack *stack) {
    if (!stack || !stack->top) return NULL;
    return stack->top->token;
}

int is_token_stack_empty(const TokenStack *stack) { return !stack || !stack->top; }
