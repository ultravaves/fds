#ifndef PLOT_H
#define PLOT_H

#include "lexer.h"

void plot_expression(TokenList *rpn);

#endif
