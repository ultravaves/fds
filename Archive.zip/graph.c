#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "lexer.h"
#include "plot.h"
#include "rpn.h"
#include "utils.h"

#define MAX_INPUT_LEN 256

int main() {
    char input[MAX_INPUT_LEN];

    if (!fgets(input, sizeof(input), stdin)) {
        printf("n/a\n");
        return 1;
    }

    input[strcspn(input, "\n")] = '\0';

    TokenList *tokens = tokenize(input);
    if (!tokens || !validate_tokens(tokens)) {
        printf("n/a\n");
        if (tokens) free_token_list(tokens);
        return 1;
    }

    TokenList *rpn = to_rpn(tokens);
    free_token_list(tokens);

    if (!rpn) {
        printf("n/a\n");
        return 1;
    }

    plot_expression(rpn);
    free_token_list(rpn);

    return 0;
}
