#include <stdio.h>
#include <stdlib.h>

void get_numbers(double *arr, int count);
int process_data(double *arr, int count);
void show_numbers(double *arr, int count);

int main()
{
    double *numbers = NULL;
    int count = 0;

    printf("How many numbers? ");
    scanf("%d", &count);

    numbers = (double*)malloc(count * sizeof(double));
    if(!numbers) {
        printf("Memory error!\n");
        return 1;
    }

    get_numbers(numbers, count);

    if(process_data(numbers, count)) {
        show_numbers(numbers, count);
    }
    else {
        printf("Processing failed\n");
    }

    free(numbers);
    return 0;
}
