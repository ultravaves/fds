#ifndef PROCESSING_H
#define PROCESSING_H

#define EPS 1E-6


int normalization(double *data, int n);

#endif




            
