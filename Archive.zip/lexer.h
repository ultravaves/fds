#ifndef LEXER_H
#define LEXER_H

typedef enum {
    TOK_NUMBER,
    TOK_VARIABLE,
    TOK_OPERATOR,
    TOK_FUNCTION,
    TOK_LPAREN,
    TOK_RPAREN,
    TOK_INVALID
} TokenType;

typedef struct Token {
    TokenType type;
    char str[16];
    struct Token *next;
} Token;

typedef struct {
    Token *head;
    Token *tail;
} TokenList;

TokenList *tokenize(const char *input);
void free_token_list(TokenList *list);

Token *new_token(TokenType type, const char *str);
void add_token(TokenList *list, Token *token);

#endif
