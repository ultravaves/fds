#ifndef STACK_H
#define STACK_H

#include "lexer.h"

typedef struct TokenNode {
    Token *token;
    struct TokenNode *next;
} TokenNode;

typedef struct {
    TokenNode *top;
} TokenStack;

TokenStack *create_token_stack();
void destroy_token_stack(TokenStack *stack);
void push_token(TokenStack *stack, Token *token);
Token *pop_token(TokenStack *stack);
Token *peek_token(TokenStack *stack);
int is_token_stack_empty(TokenStack *stack);

#endif
