#include <stdio.h>
#include <stdlib.h>

int check_data(double *values, int size);

int main()
{
    double *values;
    int num_elements;
    int i;

    printf("Enter number of elements: ");
    scanf("%d", &num_elements);

    values = (double*)malloc(num_elements * sizeof(double));
    if(values == NULL) {
        printf("Can't allocate memory\n");
        return 1;
    }

    printf("Input %d numbers (space separated): ", num_elements);
    for(i = 0; i < num_elements; i++) {
        scanf("%lf", &values[i]);
    }

    if(check_data(values, num_elements)) {
        printf("YES\n");
    }
    else {
        printf("NO\n");
    }

    free(values);
    return 0;
}
