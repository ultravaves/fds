#ifndef EVAL_H
#define EVAL_H

#include "lexer.h"

// Вычислить значение выражения в ОПН при заданном x
int evaluate_rpn(TokenList *rpn, double x, double *result_out);

#endif
