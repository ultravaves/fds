#include "plot.h"

#include <math.h>
#include <stdio.h>

#include "eval.h"

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

#define WIDTH 80
#define HEIGHT 25
#define X_START 0.0
#define X_END (4 * M_PI)
#define Y_MIN -1.0
#define Y_MAX 1.0

void plot_expression(TokenList *rpn) {
    char grid[HEIGHT][WIDTH];

    for (int row = 0; row < HEIGHT; ++row)
        for (int col = 0; col < WIDTH; ++col) grid[row][col] = '.';

    for (int col = 0; col < WIDTH; ++col) {
        double x = X_START + (X_END - X_START) * col / (WIDTH - 1);
        double y;
        if (!evaluate_rpn(rpn, x, &y)) {
            printf("n/a\n");
            return;
        }

        if (y < Y_MIN || y > Y_MAX) {
            printf("n/a\n");
            return;
        }

        int y_pos = (int)round((y - Y_MIN) / (Y_MAX - Y_MIN) * (HEIGHT - 1));
        int row = HEIGHT - 1 - y_pos;

        if (row >= 0 && row < HEIGHT) grid[row][col] = '*';
    }

    for (int r = 0; r < HEIGHT; ++r) {
        for (int c = 0; c < WIDTH; ++c) {
            putchar(grid[r][c]);
        }
        putchar('\n');
    }
}
