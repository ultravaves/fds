#include "eval.h"

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct DoubleNode {
    double value;
    struct DoubleNode *next;
} DoubleNode;

typedef struct {
    DoubleNode *top;
} DoubleStack;

static DoubleStack *create_double_stack() {
    DoubleStack *s = malloc(sizeof(DoubleStack));
    if (s) s->top = NULL;
    return s;
}

static void destroy_double_stack(DoubleStack *s) {
    while (s && s->top) {
        DoubleNode *tmp = s->top;
        s->top = s->top->next;
        free(tmp);
    }
    free(s);
}

static void push_double(DoubleStack *s, double val) {
    DoubleNode *n = malloc(sizeof(DoubleNode));
    if (!n) return;
    n->value = val;
    n->next = s->top;
    s->top = n;
}

static int pop_double(DoubleStack *s, double *out) {
    if (!s || !s->top) return 0;
    DoubleNode *n = s->top;
    s->top = n->next;
    *out = n->value;
    free(n);
    return 1;
}

int evaluate_rpn(TokenList *rpn, double x, double *result_out) {
    DoubleStack *stack = create_double_stack();
    if (!stack) return 0;

    for (Token *t = rpn->head; t; t = t->next) {
        if (t->type == TOK_NUMBER) {
            push_double(stack, atof(t->str));
        } else if (t->type == TOK_VARIABLE) {
            push_double(stack, x);
        } else if (t->type == TOK_OPERATOR) {
            double b, a;
            if (!pop_double(stack, &b)) goto error;
            if (!pop_double(stack, &a)) goto error;
            if (strcmp(t->str, "+") == 0)
                push_double(stack, a + b);
            else if (strcmp(t->str, "-") == 0)
                push_double(stack, a - b);
            else if (strcmp(t->str, "*") == 0)
                push_double(stack, a * b);
            else if (strcmp(t->str, "/") == 0) {
                if (b == 0) goto error;
                push_double(stack, a / b);
            } else
                goto error;
        } else if (t->type == TOK_FUNCTION) {
            double a;
            if (!pop_double(stack, &a)) goto error;
            if (strcmp(t->str, "sin") == 0)
                push_double(stack, sin(a));
            else if (strcmp(t->str, "cos") == 0)
                push_double(stack, cos(a));
            else if (strcmp(t->str, "tan") == 0)
                push_double(stack, tan(a));
            else if (strcmp(t->str, "ctg") == 0) {
                if (tan(a) == 0) goto error;
                push_double(stack, 1.0 / tan(a));
            } else if (strcmp(t->str, "sqrt") == 0) {
                if (a < 0) goto error;
                push_double(stack, sqrt(a));
            } else if (strcmp(t->str, "ln") == 0) {
                if (a <= 0) goto error;
                push_double(stack, log(a));
            } else
                goto error;
        } else {
            goto error;
        }
    }

    double res;
    if (!pop_double(stack, &res) || stack->top) goto error;
    *result_out = res;
    destroy_double_stack(stack);
    return 1;

error:
    destroy_double_stack(stack);
    return 0;
}
